"use client"

import type React from "react"

import { useState, useRef } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"
import { Upload, AlertCircle, CheckCircle2, FileJson } from "lucide-react"
import { parseCycloneDX } from "@/lib/sbom-parser"

export function UploadSbomDialog({ open, onOpenChange }) {
  const [file, setFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploadStatus, setUploadStatus] = useState<"idle" | "validating" | "uploading" | "success" | "error">("idle")
  const [errorMessage, setErrorMessage] = useState("")
  const [parseResult, setParseResult] = useState<any>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (!selectedFile) return

    setFile(selectedFile)
    setUploadStatus("idle")
    setErrorMessage("")
    setParseResult(null)
  }

  const validateFile = async (file: File): Promise<boolean> => {
    // Check file extension
    const validExtensions = [".json", ".xml"]
    const fileExtension = file.name.substring(file.name.lastIndexOf(".")).toLowerCase()
    if (!validExtensions.includes(fileExtension)) {
      setErrorMessage("Invalid file format. Please upload a CycloneDX file in JSON or XML format.")
      return false
    }

    // Basic content validation
    try {
      setUploadStatus("validating")
      const content = await file.text()

      // Check if it's a CycloneDX file
      if (fileExtension === ".json") {
        const json = JSON.parse(content)
        if (!json.bomFormat || json.bomFormat !== "CycloneDX") {
          setErrorMessage("The file is not a valid CycloneDX JSON file.")
          return false
        }
      } else if (fileExtension === ".xml") {
        if (!content.includes("http://cyclonedx.org/schema/bom")) {
          setErrorMessage("The file is not a valid CycloneDX XML file.")
          return false
        }
      }

      return true
    } catch (error) {
      setErrorMessage(`Error validating file: ${error.message}`)
      return false
    }
  }

  const handleUpload = async () => {
    if (!file) return

    try {
      setIsUploading(true)
      setUploadProgress(0)

      // Validate the file
      const isValid = await validateFile(file)
      if (!isValid) {
        setUploadStatus("error")
        setIsUploading(false)
        return
      }

      // Simulate upload progress
      setUploadStatus("uploading")
      const interval = setInterval(() => {
        setUploadProgress((prev) => {
          const newProgress = prev + 10
          if (newProgress >= 100) {
            clearInterval(interval)
            return 100
          }
          return newProgress
        })
      }, 200)

      // Parse the file
      const content = await file.text()
      const parseResult = await parseCycloneDX(content, file.name.endsWith(".xml"))
      setParseResult(parseResult)

      // Complete the upload
      setTimeout(() => {
        clearInterval(interval)
        setUploadProgress(100)
        setUploadStatus("success")
        setIsUploading(false)

        toast({
          title: "SBOM uploaded successfully",
          description: `${parseResult.components.length} components found in the SBOM.`,
        })
      }, 1000)
    } catch (error) {
      setErrorMessage(`Error uploading file: ${error.message}`)
      setUploadStatus("error")
      setIsUploading(false)
    }
  }

  const resetUpload = () => {
    setFile(null)
    setUploadStatus("idle")
    setUploadProgress(0)
    setErrorMessage("")
    setParseResult(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleClose = () => {
    if (!isUploading) {
      resetUpload()
      onOpenChange(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[550px]">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Upload className="mr-2 h-5 w-5" />
            Upload CycloneDX SBOM
          </DialogTitle>
          <DialogDescription>
            Upload a Software Bill of Materials (SBOM) in CycloneDX format to analyze dependencies and vulnerabilities.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {uploadStatus !== "success" ? (
            <>
              <div className="grid w-full items-center gap-1.5">
                <Label htmlFor="sbom-file">Select CycloneDX File</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="sbom-file"
                    type="file"
                    ref={fileInputRef}
                    accept=".json,.xml"
                    onChange={handleFileChange}
                    disabled={isUploading}
                    className="flex-1"
                  />
                  {file && (
                    <Button variant="outline" size="sm" onClick={resetUpload} disabled={isUploading}>
                      Clear
                    </Button>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">Supported formats: CycloneDX JSON and XML</p>
              </div>

              {file && (
                <div className="rounded-md border p-4">
                  <div className="flex items-center gap-3">
                    {file.name.endsWith(".json") ? (
                      <FileJson className="h-8 w-8 text-blue-500" />
                    ) : (
                      <FileJson className="h-8 w-8 text-orange-500" />
                    )}
                    <div className="flex-1">
                      <p className="font-medium">{file.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {(file.size / 1024).toFixed(2)} KB • {new Date().toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {uploadStatus === "uploading" && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Uploading...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <Progress value={uploadProgress} className="h-2" />
                </div>
              )}

              {uploadStatus === "error" && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{errorMessage}</AlertDescription>
                </Alert>
              )}
            </>
          ) : (
            <div className="space-y-4">
              <Alert className="border-green-500 bg-green-50">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <AlertTitle className="text-green-700">Upload Successful</AlertTitle>
                <AlertDescription className="text-green-600">
                  The SBOM has been successfully uploaded and processed.
                </AlertDescription>
              </Alert>

              <div className="rounded-md border p-4">
                <h3 className="font-medium mb-2">SBOM Summary</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Components</p>
                    <p className="font-medium">{parseResult?.components?.length || 0}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Dependencies</p>
                    <p className="font-medium">{parseResult?.dependencies?.length || 0}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Format</p>
                    <p className="font-medium">{parseResult?.format || "Unknown"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Version</p>
                    <p className="font-medium">{parseResult?.version || "Unknown"}</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          {uploadStatus !== "success" ? (
            <>
              <Button variant="outline" onClick={handleClose} disabled={isUploading}>
                Cancel
              </Button>
              <Button onClick={handleUpload} disabled={!file || isUploading}>
                {isUploading ? "Uploading..." : "Upload SBOM"}
              </Button>
            </>
          ) : (
            <Button onClick={handleClose}>Close</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
