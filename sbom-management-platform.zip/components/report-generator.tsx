"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Download, Check, FileText, AlertTriangle, Clock } from "lucide-react"

export function ReportGenerator({
  project,
  reportType,
  format,
  includeVulnerabilities,
  includeLicenses,
  includeGraph,
  onComplete,
  onCancel,
}) {
  const [progress, setProgress] = useState(0)
  const [status, setStatus] = useState("preparing") // preparing, generating, complete, error
  const [estimatedTime, setEstimatedTime] = useState("30 seconds")
  const { toast } = useToast()

  useEffect(() => {
    // Simulate report generation process
    if (status === "preparing") {
      const timer = setTimeout(() => {
        setStatus("generating")
        simulateProgress()
      }, 1500)
      return () => clearTimeout(timer)
    }
  }, [status])

  const simulateProgress = () => {
    let currentProgress = 0
    const interval = setInterval(() => {
      currentProgress += Math.random() * 15
      if (currentProgress >= 100) {
        currentProgress = 100
        clearInterval(interval)
        setProgress(100)
        setStatus("complete")
        toast({
          title: "Report generated successfully",
          description: `Your ${reportType} report is ready to download.`,
        })
      } else {
        setProgress(Math.min(currentProgress, 99))
        updateEstimatedTime(currentProgress)
      }
    }, 800)
  }

  const updateEstimatedTime = (currentProgress) => {
    if (currentProgress < 30) {
      setEstimatedTime("30 seconds")
    } else if (currentProgress < 60) {
      setEstimatedTime("20 seconds")
    } else if (currentProgress < 80) {
      setEstimatedTime("10 seconds")
    } else {
      setEstimatedTime("Almost done")
    }
  }

  const handleDownload = () => {
    toast({
      title: "Report downloaded",
      description: `${reportType.charAt(0).toUpperCase() + reportType.slice(1)} report for ${project} has been downloaded.`,
    })
    onComplete?.()
  }

  const handleCancel = () => {
    toast({
      title: "Report generation cancelled",
      description: "The report generation process has been cancelled.",
    })
    onCancel?.()
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileText className="mr-2 h-5 w-5" />
          Generating Report
        </CardTitle>
        <CardDescription>
          {status === "preparing" && "Preparing to generate your report..."}
          {status === "generating" && `Generating ${reportType} report for ${project}...`}
          {status === "complete" && "Your report is ready to download"}
          {status === "error" && "There was an error generating your report"}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-sm">Progress</span>
            <span className="text-sm font-medium">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {status !== "complete" && (
          <div className="flex items-center text-sm text-gray-500">
            <Clock className="mr-2 h-4 w-4" />
            <span>Estimated time remaining: {estimatedTime}</span>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4 pt-4">
          <div className="space-y-2">
            <h4 className="text-sm font-medium">Report Details</h4>
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-sm">Project:</span>
                <span className="text-sm font-medium">{project}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Type:</span>
                <span className="text-sm font-medium capitalize">{reportType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Format:</span>
                <span className="text-sm font-medium uppercase">{format}</span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="text-sm font-medium">Included Sections</h4>
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-sm">Vulnerabilities:</span>
                <Badge variant={includeVulnerabilities ? "default" : "outline"}>
                  {includeVulnerabilities ? "Yes" : "No"}
                </Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Licenses:</span>
                <Badge variant={includeLicenses ? "default" : "outline"}>{includeLicenses ? "Yes" : "No"}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Dependency Graph:</span>
                <Badge variant={includeGraph ? "default" : "outline"}>{includeGraph ? "Yes" : "No"}</Badge>
              </div>
            </div>
          </div>
        </div>

        {status === "complete" && (
          <div className="rounded-md bg-green-50 p-4 mt-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <Check className="h-5 w-5 text-green-400" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-green-800">Report generation complete</h3>
                <div className="mt-2 text-sm text-green-700">
                  <p>Your report has been successfully generated and is ready to download.</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {status === "error" && (
          <div className="rounded-md bg-red-50 p-4 mt-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <AlertTriangle className="h-5 w-5 text-red-400" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Report generation failed</h3>
                <div className="mt-2 text-sm text-red-700">
                  <p>There was an error generating your report. Please try again.</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-end space-x-2">
        {status !== "complete" ? (
          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
        ) : (
          <>
            <Button variant="outline" onClick={onComplete}>
              Close
            </Button>
            <Button onClick={handleDownload}>
              <Download className="mr-2 h-4 w-4" />
              Download Report
            </Button>
          </>
        )}
      </CardFooter>
    </Card>
  )
}
