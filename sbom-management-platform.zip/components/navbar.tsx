"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  ChevronDown,
  Upload,
  LogOut,
  Settings,
  UserCircle,
  Shield,
  BarChart3,
  GitCompare,
  FileText,
} from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { CompareBuildDialog } from "@/components/compare-builds-dialog"
import { GenerateReportDialog } from "@/components/generate-report-dialog"
import { ExportDataDialog } from "@/components/export-data-dialog"

export function Navbar() {
  const [compareDialogOpen, setCompareDialogOpen] = useState(false)
  const [reportDialogOpen, setReportDialogOpen] = useState(false)
  const [exportDialogOpen, setExportDialogOpen] = useState(false)
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false)

  const handleLogout = () => {
    // Handle logout logic here
    console.log("Logging out...")
  }

  return (
    <nav className="bg-[#f8f9fa] border-b border-gray-200 shadow-sm">
      <div className="container mx-auto flex justify-between items-center py-3 px-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="bg-[#e9ecef] rounded-md p-1.5">
            <Shield className="h-5 w-5 text-[#495057]" />
          </div>
          <span className="text-xl font-bold tracking-tight text-[#212529]">VulnView</span>
        </Link>

        <div className="flex items-center gap-4">
          <Button variant="ghost" className="text-[#495057] hover:text-[#212529] hover:bg-[#e9ecef]">
            <Upload className="h-4 w-4 mr-2" />
            Upload
          </Button>

          <Button variant="ghost" className="text-[#495057] hover:text-[#212529] hover:bg-[#e9ecef]" asChild>
            <Link href="/components">
              <BarChart3 className="h-4 w-4 mr-2" />
              Components
            </Link>
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="text-[#495057] hover:text-[#212529] hover:bg-[#e9ecef]">
                Actions
                <ChevronDown className="h-4 w-4 ml-2" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 bg-white border">
              <DropdownMenuItem
                onClick={() => setCompareDialogOpen(true)}
                className="flex items-center gap-2 cursor-pointer"
              >
                <GitCompare className="h-4 w-4 text-[#495057]" />
                <span>Compare Builds</span>
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => setReportDialogOpen(true)}
                className="flex items-center gap-2 cursor-pointer"
              >
                <FileText className="h-4 w-4 text-[#495057]" />
                <span>Generate Report</span>
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => setExportDialogOpen(true)}
                className="flex items-center gap-2 cursor-pointer"
              >
                <FileText className="h-4 w-4 text-[#495057]" />
                <span>Export Data</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="p-1 rounded-full">
                <Avatar className="h-8 w-8 border-2 border-gray-200">
                  <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Profile" />
                  <AvatarFallback className="bg-[#e9ecef] text-[#495057]">JD</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 bg-white border">
              <DropdownMenuItem asChild>
                <Link href="/profile" className="flex items-center gap-2">
                  <UserCircle className="h-4 w-4 text-[#495057]" />
                  <span>Profile</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/profile?tab=settings" className="flex items-center gap-2">
                  <Settings className="h-4 w-4 text-[#495057]" />
                  <span>Settings</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleLogout} className="flex items-center gap-2 text-red-600">
                <LogOut className="h-4 w-4 text-red-600" />
                <span>Logout</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      {/* Dialogs */}
      <CompareBuildDialog open={compareDialogOpen} onOpenChange={setCompareDialogOpen} />
      <GenerateReportDialog open={reportDialogOpen} onOpenChange={setReportDialogOpen} />
      <ExportDataDialog open={exportDialogOpen} onOpenChange={setExportDialogOpen} />
    </nav>
  )
}
